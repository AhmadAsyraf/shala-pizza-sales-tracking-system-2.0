<?php

session_start();

if(isset($_POST['action']))
{
	$id = $_POST["id"];
    extract($_POST);
    include 'database.php';
	echo $id;
	
	if ( $_POST[ "action" ] == "delete" ) {
            foreach ( $_SESSION[ "shopping_cart" ] as $keys => $values ) {
              if ( $values[ "item_id" ] == $_POST[ "id" ] ) {
                unset( $_SESSION[ "shopping_cart" ][ $keys ] );
                echo '<script>alert("Item Removed")</script>';
                echo '<script>window.location="create-shop-cart.php"</script>';
              }
            }
          }
	if ( $_POST[ "action" ] == "update" ) {
            foreach ( $_SESSION[ "shopping_cart" ] as $keys => $values ) {
              if ( $values[ "item_id" ] == $_POST[ "id" ] ) {
				  $id = $_POST[ "id" ];
                unset( $_SESSION[ "shopping_cart" ][ $keys ] );
                echo '<script>alert("Item update")</script>';
				echo '<script>window.location="create-product-cart.php?id='.$id.'"</script>';
              }
            }
          }
	
//	
//	$sql = "DELETE FROM staff WHERE Sta_id=$id";
//	
//    if ($conn->query($sql) === TRUE) {
//  		echo "Record deleted successfully";
//		header("Location: staff.php");
//	} else {
//	  echo "Error updating record: " . $conn->error;
//	}
}
if ( isset( $_GET[ "action" ] ) ) {
          if ( $_GET[ "action" ] == "update" ) {
            foreach ( $_SESSION[ "shopping_cart" ] as $keys => $values ) {
              if ( $values[ "item_id" ] == $_GET[ "id" ] ) {
				  $id = $_GET[ "id" ];
                unset( $_SESSION[ "shopping_cart" ][ $keys ] );
                echo '<script>alert("Item update")</script>';
				echo '<script>window.location="create-product-cart.php?id='.$id.'"</script>';
              }
            }
          }
        }
$conn->close();

?>