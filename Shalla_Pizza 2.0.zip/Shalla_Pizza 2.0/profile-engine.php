<?php

session_start();

if(isset($_POST['save']))
{
    extract($_POST);
    include 'database.php';
	
	$id = $_SESSION["Sta_id"];
    $name = $_POST['name'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	
	$sql = "Update staff SET Sta_name = '$name', Sta_phone = '$phone', Sta_address = '$address'WHERE Sta_id=$id";
	
    if ($conn->query($sql) === TRUE) {
  		echo "Record updated successfully";
		header("Location: profile.php");
	} else {
	  echo "Error updating record: " . $conn->error;
	}
}

$conn->close();
?>