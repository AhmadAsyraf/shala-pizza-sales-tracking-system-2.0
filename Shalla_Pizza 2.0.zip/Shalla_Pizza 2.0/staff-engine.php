<?php

session_start();

if(isset($_POST['save']))
{
    extract($_POST);
    include 'database.php';
	
	$id = $_POST["byId"];
    $name = $_POST['name'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	
	$sql = "Update staff SET Sta_name = '$name', Sta_phone = '$phone', Sta_address = '$address' WHERE Sta_id=$id";
	
    if ($conn->query($sql) === TRUE) {
  		echo "Record updated successfully";
		header("Location: staff.php");
	} else {
	  echo "Error updating record: " . $conn->error;
	}
}else if(isset($_POST['add'])){
	
	extract($_POST);
    include 'database.php';
	
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];

	$sql = "INSERT INTO staff (Sta_name, Sta_phone, Sta_address)
	VALUES ('$name', $phone, '$address')";

	if ($conn->query($sql) === TRUE) {
	  echo "New Order created successfully";
	  echo '<script>alert("Order Already Added")</script>';
        echo '<script>window.location="shop-cart.php"</script>';	
	  // Redirect browser
	  header("Location: staff.php");
	  exit;
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
}

$conn->close();
?>