<?php

session_start();

if(isset($_POST['save']))
{
    extract($_POST);
    include 'database.php';
	
	$id = $_POST["byId"];
    $name = $_POST['name'];
	$price = $_POST['price'];
	$type = $_POST['type'];
	
	$sql = "Update pizza SET Pizza_name = '$name', Price = '$price', Pizza_type = '$type' WHERE Pizza_id=$id";
	
    if ($conn->query($sql) === TRUE) {
  		echo "Record updated successfully";
		header("Location: menu.php");
	} else {
	  echo "Error updating record: " . $conn->error;
	}
}else if(isset($_POST['add'])){
	
	extract($_POST);
    include 'database.php';
	
	$name = $_POST['name'];
	$price = $_POST['price'];
	$type = $_POST['type'];

	$sql = "INSERT INTO pizza (Pizza_name, Price, Pizza_type)
	VALUES ('$name', $price, '$type')";

	if ($conn->query($sql) === TRUE) {
	  echo "New record created successfully";
	  // Redirect browser
	  header("Location: menu.php");
	  exit;
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
}

$conn->close();
?>