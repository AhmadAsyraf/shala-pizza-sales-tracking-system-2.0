<?php

session_start();
if ( isset( $_POST[ 'checkout' ] ) ) {

  extract( $_POST );
  include 'database.php';
	
  $name = $_SESSION[ 'name' ];
  $phone = $_SESSION[ 'phone' ];
  $date = $_SESSION[ 'date' ];
  $payment = $_SESSION[ 'payment' ];
  $total = $_POST[ 'total' ];
  $receipt = "$date$phone";
  $item_array = $_SESSION[ 'shopping_cart' ];

  echo $payment;
  echo $name;
  echo $phone;
  echo $date;
  echo $total;
  echo $receipt;
  echo var_dump( $item_array );
  $OrderId = 0;

  function option1( $array, $conn ) {
    if ( is_array( $array ) ) {
      foreach ( $array as $row => $value ) {
        $name = $_SESSION['name'];
        $sql1 = "select * from orders where Cust_name='$name'";
        $result = mysqli_query( $conn, $sql1);
        while ( $row1 = mysqli_fetch_array( $result ) ) {
          $OrderId = $row1[ 'Order_id' ];
          echo $OrderId;
        }
        //$item_id = mysqli_real_escape_string( $conn, $value[ "item_id" ] );
        $item_id = mysqli_real_escape_string( $conn, $value[ "item_id" ] );
        $item_quantity = mysqli_real_escape_string( $conn, $value[ "item_quantity" ] );

        $sql = "INSERT INTO orderpizza(Order_id, Pizza_id, Quantity) VALUES ($OrderId,'" . $item_id . "', '" . $item_quantity . "')";
        mysqli_query( $conn, $sql );
      }
    }
  }
  $conn = mysqli_connect( "localhost", "root", "", "shala_pizza" );
  $sql = "INSERT INTO orders (Cust_name, Phone, Order_date, Order_payment_methode, Order_Total_Payment, Order_receipt_number, Status) VALUES ('$name', '$phone', '$date', '$payment', '$total', '$receipt', 'Pending')";

  if ( $conn->query( $sql ) === TRUE ) {
    echo "New Order created successfully";
    echo '<script>alert("Order Already Added")</script>';
    option1( $item_array, $conn );
    echo '<script>alert("OrderPizza Already Added")</script>';
	unset($_SESSION['name']);
	unset($_SESSION['phone']);
	unset($_SESSION['date']);
	unset($_SESSION['payment']);
	unset($_SESSION['shopping_cart']);
    // Redirect browser
    header( "Location: order.php" );
    exit;

  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
	$conn->close();	
}



if(isset($_POST['DoneById'])){
	
	extract($_POST);
    include 'database.php';
	
	$id = $_POST["id"];
	
	$sql = "Update orders SET Status = 'Finish' WHERE Order_id=$id";
	
    if ($conn->query($sql) === TRUE) {
  		echo "Record updated successfully";
		echo "<script>alert('status has been update')</script>";
		echo "<script>window.location.href='order.php';</script>";
	} else {
	  echo "Error updating record: " . $conn->error;
	}
	$conn->close();
}

if(isset($_POST['create-order'])){
	
	extract($_POST);
	
	$_SESSION["name"] = $_POST['name'];
	$_SESSION["phone"] = $_POST['phone'];
	$_SESSION["date"] = $_POST['date'];
	$_SESSION["payment"] = $_POST['payment'];
	
	echo $_SESSION["name"];
	echo $_SESSION["phone"];
	echo $_SESSION["date"];
	echo $_SESSION["payment"];
	
	echo "<script>window.location.href='create-product.php';</script>";
	///header("Location : create-product.php");
	
}


?>