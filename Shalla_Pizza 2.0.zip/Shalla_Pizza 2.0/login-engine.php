<?php

session_start();
if(isset($_POST['login']))
{
    extract($_POST);
    include 'database.php';
    
	$sql = "SELECT * FROM staff WHERE Sta_phone=$phone";
	
    $result = mysqli_query($conn,$sql);
	$row  = mysqli_fetch_array($result);
	
    if(is_array($row) == 1)
    {
        $_SESSION["Sta_id"] = $row['Sta_id'];
        $_SESSION["Sta_name"] = $row['Sta_name'];
        $_SESSION["Sta_phone"] = $row['Sta_phone'];
        $_SESSION["Sta_address"] = $row['Sta_address']; 
        header("Location: index.php"); 
    }
//    else
//    {
//		$sql = "SELECT * FROM customer WHERE Cust_phone=$phone";
//	
//		$result = mysqli_query($conn,$sql);
//		$row  = mysqli_fetch_array($result);
//		if(is_array($row) == 1)
//		{
//			$_SESSION["Cust_id"] = $row['Cust_id'];
//			$_SESSION["Cust_name"] = $row['Cust_name'];
//			$_SESSION["Cust_phone"] = $row['Cust_phone'];
//			$_SESSION["Cust_add"] = $row['Sta_add']; 
//			header("Location: home.php"); 
//		}
		else
		{
			echo "Invalid Email ID/Password";
			header("Location: login.php"); 
		}
}

$conn->close();
?>