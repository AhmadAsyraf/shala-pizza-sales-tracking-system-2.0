<?php

session_start();

if(isset($_POST['deleteById']))
{
	$id = $_POST["deleteById"];
    extract($_POST);
    include 'database.php';
	
	$sql = "DELETE FROM pizza WHERE Pizza_id=$id";
	
    if ($conn->query($sql) === TRUE) {
  		echo "Record deleted successfully";
		header("Location: menu.php");
	} else {
	  echo "Error updating record: " . $conn->error;
	}
}

$conn->close();
?>